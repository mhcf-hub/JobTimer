package com.example.jobtimer;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Timer;
import java.util.TimerTask;

import static android.provider.Contacts.SettingsColumns.KEY;

public class SingleJob extends AppCompatActivity {


    AllJobs allJobs;

    TextView title;
    EditText editTitle;

    View colorChcosen;

    View viewColor0;
    View viewColor1;
    View viewColor2;
    View viewColor3;

    Button singleJobSave;
    Button singleJobStart;
    Button singleJobBack;
    Button singleJobStop;

    String start;
    String stop;
    SimpleDateFormat timeStart;
    SimpleDateFormat timeStop;

    Calendar cal;
    Calendar calStop;

    Date now;
    Date then;

    int idIn;

    TextView startDate;


    private Timer myTimer;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_single_job);

        startDate = (TextView) findViewById(R.id.textViewStartDate);
        startDate.setText("Start Date:");

        myTimer = new Timer();

        allJobs = new AllJobs();
        load();

        Intent intent = getIntent();
        final int id = intent.getIntExtra("id", 9);
        idIn = id;
        System.out.println(allJobs.getJobs().get(id).getColor() + " id");
        System.out.println(allJobs.getJobs().get(id).getTitle() + " id");

        final String jobTitle = allJobs.getJobs().get(id).getTitle();
        final int jobColor = allJobs.getJobs().get(id).getColor();

        title = (TextView) findViewById(R.id.textSingleJobTitle);
        editTitle = (EditText) findViewById(R.id.editTextTitle);

        title.setText(jobTitle + "");
        editTitle.setText(jobTitle + "");

        colorChcosen = (View) findViewById(R.id.viewColorChosen);

        viewColor0  = (View) findViewById(R.id.viewColor0);
        viewColor1  = (View) findViewById(R.id.viewColor1);
        viewColor2  = (View) findViewById(R.id.viewColor2);
        viewColor3  = (View) findViewById(R.id.viewColor3);

        colorChcosen.setBackgroundColor(jobColor);

        viewColor0.setBackgroundColor(getResources().getColor(R.color.blue));
        viewColor1.setBackgroundColor(getResources().getColor(R.color.red));
        viewColor2.setBackgroundColor(getResources().getColor(R.color.green));
        viewColor3.setBackgroundColor(getResources().getColor(R.color.yellow));

        viewColor0.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                colorChcosen.setBackgroundColor(getResources().getColor(R.color.blue));
            }
        });

        viewColor1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                colorChcosen.setBackgroundColor(getResources().getColor(R.color.red));
            }
        });

        viewColor2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                colorChcosen.setBackgroundColor(getResources().getColor(R.color.green));
            }
        });

        viewColor3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                colorChcosen.setBackgroundColor(getResources().getColor(R.color.yellow));
            }
        });

        singleJobSave = (Button) findViewById(R.id.buttonSingleSave);
        singleJobStart = (Button) findViewById(R.id.buttonSingleStart);
        singleJobBack = (Button) findViewById(R.id.buttonSingleBack);
        singleJobStop = (Button) findViewById(R.id.buttonSingleStop);

        singleJobSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                allJobs.getJobs().get(id).setTitle(editTitle.getText().toString());

                int color = Color.TRANSPARENT;
                Drawable background = colorChcosen.getBackground();
                if (background instanceof ColorDrawable)
                    color = ((ColorDrawable) background).getColor();
                allJobs.getJobs().get(id).setColor(color);
                title.setText(editTitle.getText());
                save();

            }
        });

        singleJobStart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               cal = Calendar.getInstance();
               now = cal.getTime();


                myTimer.schedule(new TimerTask() {
                    @Override
                    public void run() {
                        TimerMethod();
                    }

                }, 0, 1000);
                timeStart = new SimpleDateFormat("dd.MM.YYYY - HH:mm");
                String nowString = timeStart.format(now);
                startDate.setText("Start Date: " + nowString);
                allJobs.setRunning(true);
                allJobs.getJobs().get(id).setRunning(true);
                save();

            }
        });

        singleJobStop.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                System.out.println(secondsCounted + " test");
                myTimer.cancel();
                myTimer = null;
                allJobs.setRunning(false);
                for (Job job : allJobs.getJobs()){
                    job.setRunning(false);
                }
                save();


//                calStop = Calendar.getInstance();
//
//
//                calStop.set(Calendar.YEAR, 2013);
//                calStop.set(Calendar.MONTH, 6);
//                calStop.set(Calendar.DAY_OF_MONTH, 17);
//                calStop.set(Calendar.HOUR_OF_DAY, 22);
//                calStop.set(Calendar.MINUTE, 4);
//                calStop.set(Calendar.SECOND, 0);
//
//                timeStop = new SimpleDateFormat("HH:mm:ss.SSS");
//                String nowString = timeStop.format(calStop.getTime());
//                Log.e("TEST TOGETHER", nowString);
//
//                Log.e("TEST", (calStop.getTime().getMinutes() - now.getMinutes()) + " " + (calStop.getTime().getHours() - now.getHours()));




            }
        });

        singleJobBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(SingleJob.this, JobsOverview.class);
                startActivity(intent);
            }
        });



    }



    private void TimerMethod()
    {
        //This method is called directly by the timer
        //and runs in the same thread as the timer.




        //We call the method that will work with the UI
        //through the runOnUiThread method.
        this.runOnUiThread(Timer_Tick);
    }

int secondsCounted = 0;
    private Runnable Timer_Tick = new Runnable() {
        public void run() {
            secondsCounted++;
            System.out.println(secondsCounted + " testor");
        }
    };


    public void load(){
        try {
            allJobs =  (AllJobs) InternalStorage.readObject(this, KEY);
        } catch (IOException e) {
            System.out.println(e + " e1");
        } catch (ClassNotFoundException e) {
            System.out.println(e + " e2");
        }


    }


    public void save(){

        try {
            // Save the list of entries to internal storage
            InternalStorage.writeObject(this, KEY, allJobs);
        } catch (IOException e) {
            System.out.println(e + " e2");
        }
    }
}
