package com.example.jobtimer;

import android.graphics.Color;

import java.io.Serializable;
import java.util.Timer;

public class Job implements Serializable {
    String title;
    int color;
    int id;
    int seconds;
    boolean running;

    public Job(String title, int color, int id) {
        this.title = title;
        this.color = color;
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public int getColor() {
        return color;
    }

    public void setColor(int color) {
        this.color = color;
    }


    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getSeconds() {
        return seconds;
    }

    public void setSeconds(int seconds) {
        this.seconds = seconds;
    }

    public boolean isRunning() {
        return running;
    }

    public void setRunning(boolean running) {
        this.running = running;
    }

    int zero;
}
