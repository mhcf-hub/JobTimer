package com.example.jobtimer;

import android.content.Intent;
import android.support.constraint.ConstraintLayout;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import static android.provider.Contacts.SettingsColumns.KEY;

public class JobsOverview extends AppCompatActivity {

    AllJobs allJobs;

    ScrollView scrollViewJobs;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_jobs_overview);


        final float scale = this.getResources().getDisplayMetrics().density;

        allJobs = new AllJobs();
        load();
        if(!allJobs.isRunning()){
        scrollViewJobs = (ScrollView) findViewById(R.id.scrollViewJobs);

        LinearLayout linearLayout = new LinearLayout(this);
        LinearLayout.LayoutParams linearParams = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        linearLayout.setOrientation(LinearLayout.VERTICAL);
        linearParams.setMargins(0, 0, 0, 0);
        linearLayout.setLayoutParams(linearParams);

        scrollViewJobs.addView(linearLayout);

        List<Job> jobs = new ArrayList<Job>();
        jobs = allJobs.getJobs();

        for (final Job job : jobs){
            LinearLayout linearLayout2 = new LinearLayout(this);
            LinearLayout.LayoutParams linearparams3 = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            linearLayout2.setOrientation(LinearLayout.VERTICAL);
            linearparams3.setMargins(0, 10, 0, 60);

            linearLayout2.setLayoutParams(linearparams3);

            ConstraintLayout.LayoutParams constParams = new ConstraintLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            constParams.setMargins(0, 0, 0, 0);

            ConstraintLayout constColor = new ConstraintLayout(this);
            constColor.setLayoutParams(constParams);

            int constHeight = (int) (55 * scale + 0.5f);
            constColor.getLayoutParams().height = constHeight;

            constColor.setBackgroundColor(job.getColor());


            TextView textView = new TextView (this);
            textView.setText("Title: " + job.getTitle().toUpperCase());

            linearLayout2.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    singleJob(job.getId());
                }
            });

            linearLayout2.addView(constColor);
            linearLayout2.addView(textView);
            linearLayout.addView(linearLayout2);
        }
        } else {
            Intent intent = new Intent(JobsOverview.this, JobRunning.class);
            startActivity(intent);
        }

    }

    public void singleJob(int id){
        Intent intent = new Intent(JobsOverview.this, SingleJob.class);
        intent.putExtra("id", id);
        startActivity(intent);
    }

    public void load(){
        try {
            allJobs =  (AllJobs) InternalStorage.readObject(this, KEY);
        } catch (IOException e) {
            System.out.println(e + " e1");
        } catch (ClassNotFoundException e) {
            System.out.println(e + " e2");
        }


    }


    public void save(){

        try {
            // Save the list of entries to internal storage
            InternalStorage.writeObject(this, KEY, allJobs);
        } catch (IOException e) {
            System.out.println(e + " e2");
        }
    }
}
